<template>
  <router-view />
</template>

<script>

export default {
  name: 'LayoutDefault',

  components: {
  },

  setup() {
    return {
    }
  }
}
</script>
