<template>
  <router-view></router-view>
</template>
<script>
//   import Header from "../components/Header.vue";
//   import Sidebar from "../components/Sidebar.vue";

export default {
  components: {
    //   Header,
    //   Sidebar,
  },
  data: function () {
    return {

    };
  },
  props: {},
  methods: {
  },
  mounted() {

  },
};
</script>
  
<style scoped>

</style>
  